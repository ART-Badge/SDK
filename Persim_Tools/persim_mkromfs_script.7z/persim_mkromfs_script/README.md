#### 使用方法

1. env 下执行命令：`python3 _bin_mkromfs.py --binary --addr 0x00A00000 root root.bin`。
2. Shift + 右键打开 Linux Shell，执行命令：`python3 _bin_mkromfs.py --binary --addr 0x00A00000 root root.bin`。

#### 注意事项

1. `0x00A00000` 该地址根据系统工程中的文件系统挂载地址对应修改。